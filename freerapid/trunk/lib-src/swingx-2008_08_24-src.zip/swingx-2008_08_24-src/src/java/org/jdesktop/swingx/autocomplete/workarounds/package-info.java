/**
 * Contains classes to workaround Look and Feel implemetation problems caused
 * when applying the autocomplete decorators.
 */
package org.jdesktop.swingx.autocomplete.workarounds;

