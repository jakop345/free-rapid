/**
 * Contains classes and interfaces used by painter enabled components.
 */
package org.jdesktop.swingx.painter;

