/*
 * $Id: StringValue.java,v 1.2 2007/05/17 09:52:38 kleopatra Exp $
 *
 * Copyright 2006 Sun Microsystems, Inc., 4150 Network Circle,
 * Santa Clara, California 95054, U.S.A. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
package org.jdesktop.swingx.renderer;

import java.io.Serializable;


/**
 * A simplistic converter to return a String representation of an object. <p>
 * 
 * PENDING: use a  full-fledged Format instead? Would impose a higher 
 * burden onto implementors but could be re-used in editors.
 * 
 * @author Jeanette Winzenburg
 */
public interface StringValue extends Serializable {
    
    /**
     * Default converter using the toString.
     */
    public final static StringValue TO_STRING = new StringValue() {

        /**
         * {@inheritDoc} <p>
         * 
         * Implemented to return the values toString if value not-null. Otherwise,
         * returns an empty string.
         */
        public String getString(Object value) {
            return (value != null) ? value.toString() : "";
        }
        
    };
    
    /**
     * Converter returning an empty String always.
     */
    public final static StringValue EMPTY = new StringValue() {

        /**
         * {@inheritDoc} <p>
         * 
         * Implemented to return an empty string.
         */
        public String getString(Object value) {
            return "";
        }
        
    };
    /**
     * Returns a string representation of the given value.
     * 
     * @param value the object to present as a string
     * @return a string representation of the given value, 
     *  guaranteed to be not null
     */
    String getString(Object value);
}
