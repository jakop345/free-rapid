import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import net.miginfocom.layout.LayoutUtil;
import net.miginfocom.swt.MigLayout;

/**
 * @author Mikael Grev, MiG InfoCom AB
 *         Date: 2007-jul-08
 *         Time: 10:14:13
 */
public class SWTTes
{
	   public static void main(String[] args) {
         System.out.println(LayoutUtil.getVersion());

         Display display = new Display();
         Shell shell = new Shell();
         shell.setLayout(new FillLayout());

         SashForm sash = new SashForm(shell, SWT.HORIZONTAL);

         final Composite parent = new Composite(sash, SWT.NONE);
         parent.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
         parent.setLayout(new MigLayout("fillx"));

         Label styledText = new Label(parent, SWT.WRAP);
         StringBuffer b = new StringBuffer();
         b.append("Galia est omnis divisa in partes tres. Quorum unam incolunt");
         b.append(" Belgae aliam Aquitani. Tertiam qui ipsorum lingua Celtae nostra");
         b.append(" Gali apelantur.\n\nAve Caesar morituri te salutant!");
         styledText.setText(b.toString());
         styledText.setLayoutData("wmin 100");
         styledText.setBackground(shell.getDisplay().getSystemColor(SWT.COLOR_RED));

         // empty composite on the right side of the sash
         new Composite(sash, SWT.BORDER);
         sash.setWeights(new int[] { 50, 50 });

         shell.setSize(400, 400);
         shell.open();
         shell.layout();

         while(!shell.isDisposed()){
            if(!display.readAndDispatch())
               display.sleep();
         }
   }
}
